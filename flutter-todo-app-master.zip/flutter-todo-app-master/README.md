# Flutter ToDo App

A basic to-do app built with Flutter. This app has add/delete/update functinality with search for any existing to-do item in the app.

## Watch it on YouTube
This repository is part of a tutorial on my YouTube.
- [Flutter ToDo App Tutorial for Beginners](https://youtu.be/K4P5DZ9TRns)

## Screenshot

![Flutter todo app](./flutter-todo-iphone.png)
